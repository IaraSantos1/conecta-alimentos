import React from 'react';
import './Education.css';

function Education() {
  return (
    <div className="education-bg">
      <h2 className="education-titulo">🍎 Conteúdo Educativo</h2>
      <div className="education-carrossel">
        <div className="education-card">
          <h3>Como aproveitar talos e cascas</h3>
          <p>Dicas para evitar desperdício e valorizar cada alimento!</p>
        </div>
        <div className="education-card">
          <h3>Receitas nutritivas com alimentos regionais</h3>
          <p>Veja receitas fáceis e saborosas usando o que há de melhor na região.</p>
        </div>
        <div className="education-card">
          <h3>Histórias de produtores locais</h3>
          <p>Conheça quem produz o seu alimento e suas jornadas.</p>
        </div>
      </div>
    </div>
  );
}

export default Education;