import React from 'react';
import './Producer.css';

function Producer() {
  return (
    <div className="producer-bg">
      <h2 className="producer-titulo">👩‍🌾 Perfil do Produtor</h2>
      <div className="producer-perfil">
        <img src="/assets/producer.jpg" alt="Produtor" className="producer-avatar" />
        <div>
          <p><strong>Nome:</strong> Maria Oliveira</p>
          <p><strong>Localização:</strong> 📍 Caxias do Sul</p>
        </div>
      </div>
      <div className="producer-produtos">
        <h3>Produtos disponíveis</h3>
        <ul>
          <li>Tomate Orgânico</li>
          <li>Alface Crespa</li>
          <li>Abóbora</li>
        </ul>
      </div>
      <button className="producer-btn">✉️ Enviar mensagem</button>
      <button className="producer-btn">🟢 Chamar no WhatsApp</button>
    </div>
  );
}

export default Producer;