import React from 'react';
import './Payment.css';

function Payment() {
  return (
    <div className="payment-bg">
      <h2 className="payment-titulo">💳 Pagamento</h2>
      <div className="payment-metodos">
        <button className="payment-btn">PIX 🟣</button>
        <button className="payment-btn">Cartão 💳</button>
        <button className="payment-btn">Dinheiro 💵</button>
      </div>
      <div className="payment-agendamento">
        <label>Agendar entrega:</label>
        <input type="date" className="payment-date"/>
      </div>
      <div className="payment-confirmacao">
        <button className="payment-confirm-btn">Confirmar pedido</button>
      </div>
    </div>
  );
}

export default Payment;