import React, { useState } from 'react';
import './Catalog.css';

const produtosExemplo = [
  {
    id: 1,
    nome: 'Tomate Orgânico',
    preco: 'R$ 5,00/kg',
    origem: 'Caxias do Sul',
    imagem: '/assets/tomate.jpg',
  },
  {
    id: 2,
    nome: 'Banana',
    preco: 'R$ 3,50/kg',
    origem: 'Taquara',
    imagem: '/assets/banana.jpg',
  },
  {
    id: 3,
    nome: 'Abóbora',
    preco: 'R$ 2,00/kg',
    origem: 'Pelotas',
    imagem: '/assets/abobora.jpg',
  },
];

function Catalog() {
  const [filtro, setFiltro] = useState('');

  const produtosFiltrados = produtosExemplo.filter(
    (p) => p.nome.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className="catalog-bg">
      <h2 className="catalog-titulo">🥕 Catálogo de Produtos</h2>
      <div className="catalog-filtros">
        <input
          type="text"
          placeholder="🔎 Buscar alimento..."
          value={filtro}
          onChange={e => setFiltro(e.target.value)}
        />
      </div>
      <div className="catalog-grid">
        {produtosFiltrados.map(produto => (
          <div className="catalog-card" key={produto.id}>
            <img src={produto.imagem} alt={produto.nome} className="catalog-img" />
            <h3>{produto.nome}</h3>
            <p className="catalog-preco">💰 {produto.preco}</p>
            <p className="catalog-origem">📍 {produto.origem}</p>
            <button className="catalog-btn">Adicionar ao carrinho</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Catalog;