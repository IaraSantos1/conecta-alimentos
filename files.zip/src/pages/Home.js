import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

function Home() {
  return (
    <div className="home-bg">
      <h1>Conecta Alimento</h1>
      <div className="home-buttons">
        <Link to="/catalog" className="home-btn">🛒 Comprar alimentos</Link>
        <Link to="/producer" className="home-btn">👩‍🌾 Sou produtor</Link>
        <Link to="/donation" className="home-btn">🎁 Doar alimentos</Link>
        <Link to="/education" className="home-btn">🍎 Conteúdo educativo</Link>
      </div>
    </div>
  );
}

export default Home;