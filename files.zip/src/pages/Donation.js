import React from 'react';
import './Donation.css';

function Donation() {
  return (
    <div className="donation-bg">
      <h2 className="donation-titulo">🎁 Doação de Alimentos</h2>
      <div className="donation-form">
        <label>Tipo de alimento:</label>
        <input type="text" placeholder="Ex: Banana, arroz..." />
        <label>Quantidade:</label>
        <input type="number" placeholder="Ex: 5kg, 10 itens..." />
        <div className="donation-opcoes">
          <button className="donation-btn">Entregar em ONG próxima</button>
          <button className="donation-btn">Solicitar coleta</button>
        </div>
      </div>
      <div className="donation-instituicoes">
        <h3>Instituições parceiras</h3>
        <ul>
          <li>ONG Bem Viver - Caxias do Sul</li>
          <li>Rede Solidária - Taquara</li>
        </ul>
      </div>
    </div>
  );
}

export default Donation;