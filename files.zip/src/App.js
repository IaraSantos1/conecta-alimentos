import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import Producer from './pages/Producer';
import Payment from './pages/Payment';
import Donation from './pages/Donation';
import Education from './pages/Education';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div style={{ paddingBottom: 60 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/producer" element={<Producer />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/donation" element={<Donation />} />
          <Route path="/education" element={<Education />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;